# Moje repo

Tohle je moje skvely repo *(bohuzel)* hostly na githubu.
![climbing](images/climbing.jpg)
![social studies](images/SS_0.jpeg)
[github, ale actually dobrej](https://codeberg.org/)

- boulder
- fachwerk
- shelter
- office

[kuba tajny](https://jakubhajny.cz/)

zaver: takhle se git uplne nepouziva a github je na nic
